<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/../../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Utilisateur non connecté']);
    exit;
}
$user_id = $_SESSION['user_id'];
$method = $_SERVER['REQUEST_METHOD'];

try {
    if ($method === 'GET') {
        $stmt = $pdo->prepare("SELECT * FROM projets WHERE user_id=?");
        $stmt->execute([$user_id]);
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }
    elseif ($method === 'POST') {
        $data = json_decode(file_get_contents('php://input'), true);
        $stmt = $pdo->prepare("INSERT INTO projets (user_id, nom, annee, type, image, description_courte, description_detaillee, lien) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$user_id, $data['nom'], $data['annee'], $data['type'], $data['image'], $data['description_courte'], $data['description_detaillee'], $data['lien']]);
        echo json_encode(['id'=>$pdo->lastInsertId()] + $data);
    }
    elseif ($method === 'PUT') {
        $data = json_decode(file_get_contents('php://input'), true);
        $stmt = $pdo->prepare("UPDATE projets SET nom=?, annee=?, type=?, image=?, description_courte=?, description_detaillee=?, lien=? WHERE id=? AND user_id=?");
        $stmt->execute([$data['nom'], $data['annee'], $data['type'], $data['image'], $data['description_courte'], $data['description_detaillee'], $data['lien'], $data['id'], $user_id]);
        echo json_encode($data);
    }
    elseif ($method === 'DELETE') {
        $data = json_decode(file_get_contents('php://input'), true);
        $stmt = $pdo->prepare("DELETE FROM projets WHERE id=? AND user_id=?");
        $stmt->execute([$data['id'], $user_id]);
        echo json_encode(['success'=>true]);
    }
} catch (Exception $e) { echo json_encode(['error'=>$e->getMessage()]); }
